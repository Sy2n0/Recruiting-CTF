#ifndef CMARK_MODULE_H
#define CMARK_MODULE_H

#ifdef __cplusplus
extern "C" {
#endif

#define CMARKEXTENSIONS_STATIC_DEFINE

#include "cmark-gfm.h"
#include "cmark-gfm-extension_api.h"
#include "cmark-gfm-core-extensions.h"

#ifdef __cplusplus
}
#endif

#endif
